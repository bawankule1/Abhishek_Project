import InputLink from "../components/InputLink";
import ThrowStatement from "../components/ThrowStatement";
import styled from "styled-components";
import ErrorHandler from "../components/ErrorHandler";
import FrameComponent3 from "../components/FrameComponent3";
import DataGatherer from "../components/DataGatherer";
import FrameComponent2 from "../components/FrameComponent2";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";
import DatabaseSchema from "../components/DatabaseSchema";
import CalendarPicker from "../components/CalendarPicker";

const TreeTrunk = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  max-width: 100%;
`;
const BookADemo = styled.div`
  width: 120px;
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  min-width: 120px;
`;
const VectorIcon = styled.img`
  height: 0px;
  width: 18px;
  position: relative;
`;
const VectorIcon1 = styled.img`
  height: 14px;
  width: 7px;
  position: relative;
  margin-left: -5px;
`;
const Arrow = styled.div`
  width: 1px;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const SimpleButton = styled.div`
  width: 180px;
  border-radius: var(--br-3xs);
  background-color: var(--white);
  box-shadow: 0px 8px 40px rgba(0, 0, 0, 0.22);
  border: 2px solid var(--primary-100);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-9xl);
  gap: var(--gap-base);
`;
const SimpleButtonWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl) var(--padding-37xl);
`;
const FrameParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 77px;
  max-width: 100%;
  @media screen and (max-width: 825px) {
    gap: 38px 77px;
  }
  @media screen and (max-width: 450px) {
    gap: 19px 77px;
  }
`;
const ForEmployersInner = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px var(--padding-12xs) 84px;
  box-sizing: border-box;
  max-width: 100%;
  @media screen and (max-width: 1400px) {
    padding-bottom: 55px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 825px) {
    padding-bottom: var(--padding-17xl);
    box-sizing: border-box;
  }
`;
const OptimizeYourHiring = styled.h1`
  margin: 0;
  position: absolute;
  top: 0px;
  left: 0px;
  font-size: inherit;
  font-weight: 400;
  font-family: inherit;
  display: flex;
  align-items: center;
  width: 1175px;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-15xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
  }
`;
const RequestYourFree = styled.div`
  position: relative;
  line-height: 28px;
  font-weight: 500;
`;
const CtaButton = styled.div`
  position: absolute;
  top: 62px;
  left: 134px;
  border-radius: var(--br-xl);
  background-color: var(--primary-100);
  box-shadow: 0px 8px 18px rgba(174, 93, 255, 0.46);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-2xl) var(--padding-37xl);
  white-space: nowrap;
  z-index: 1;
  font-size: var(--font-size-5xl);
  color: var(--color-snow);
  font-family: var(--font-poppins);
`;
const OptimizeYourHiringStrategyParent = styled.div`
  align-self: stretch;
  height: 132px;
  position: relative;
`;
const DiscoverTheStrengths = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-lg);
  font-family: var(--font-poppins);
  color: var(--color-gray-300);
`;
const TagCloud = styled.div`
  width: 1175px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-7xs);
  max-width: 100%;
`;
const NotificationCenter = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-16xl) 0px var(--padding-xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-23xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-semibold);
`;
const ForEmployersRoot = styled.div`
  width: 100%;
  position: relative;
  background-color: #fdfdfd;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  padding: 0px 0px 1273px;
  box-sizing: border-box;
  letter-spacing: normal;
  text-align: center;
  font-size: var(--font-size-lg);
  color: var(--primary-100);
  font-family: var(--font-poppins);
`;

const ForEmployers = () => {
  return (
    <ForEmployersRoot>
      <TreeTrunk>
        <InputLink />
        <ThrowStatement />
      </TreeTrunk>
      <ErrorHandler />
      <FrameComponent3 />
      <DataGatherer />
      <SimpleButtonWrapper>
        <SimpleButton>
          <BookADemo>Book a Demo</BookADemo>
          <Arrow>
            <VectorIcon alt="" src="/vector.svg" />
            <VectorIcon1 alt="" src="/vector-1.svg" />
          </Arrow>
        </SimpleButton>
      </SimpleButtonWrapper>
      <FrameComponent2 />
      <FrameComponent1 />
      <ForEmployersInner>
        <FrameParent>
          <FrameComponent />
          <DatabaseSchema />
        </FrameParent>
      </ForEmployersInner>
      <CalendarPicker />
      <NotificationCenter>
        <TagCloud>
          <OptimizeYourHiringStrategyParent>
            <OptimizeYourHiring>
              Optimize Your Hiring Strategy with Rework's Exclusive Hiring Audit
            </OptimizeYourHiring>
            <CtaButton>
              <RequestYourFree>Request Your Free Hiring Audit</RequestYourFree>
            </CtaButton>
          </OptimizeYourHiringStrategyParent>
          <DiscoverTheStrengths>
            Discover the strengths and opportunities in your current hiring
            process. Our comprehensive Hiring Audit evaluates your strategy,
            identifies areas for improvement, and tailors a roadmap for success.
            Elevate your recruitment game with data-driven insights – because
            the right talent deserves the right approach.
          </DiscoverTheStrengths>
        </TagCloud>
      </NotificationCenter>
    </ForEmployersRoot>
  );
};

export default ForEmployers;
