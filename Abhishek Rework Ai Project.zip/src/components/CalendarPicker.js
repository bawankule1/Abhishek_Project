import styled from "styled-components";

const FrequentlyAsked = styled.span``;
const Questions = styled.span`
  font-family: var(--font-garnett-regular);
`;
const FrequentlyAskedQuestionsContainer = styled.h1`
  margin: 0;
  height: 59px;
  flex: 1;
  position: relative;
  font-size: inherit;
  display: inline-block;
  max-width: 100%;
  font-family: inherit;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-15xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
  }
`;
const FrequentlyAskedQuestionsWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px var(--padding-59xl) 0px var(--padding-60xl);
  box-sizing: border-box;
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    padding-left: var(--padding-20xl);
    padding-right: var(--padding-20xl);
    box-sizing: border-box;
  }
`;
const WeHaveCompiled = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-base);
  line-height: 22px;
  font-family: var(--font-poppins);
  color: var(--black);
`;
const FrameParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-3xl);
  max-width: 100%;
`;
const HeroInner = styled.div`
  width: 854px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-lg);
  box-sizing: border-box;
  max-width: 100%;
`;
const HowCanI = styled.div`
  position: relative;
  line-height: 22px;
  font-weight: 500;
`;
const TypcnplusIcon = styled.img`
  width: 24px;
  height: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const TypcnplusWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px var(--padding-12xs);
`;
const HowCanIGetStartedWithRewParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--gap-xl);
`;
const LoremIpsumDolor = styled.div`
  align-self: stretch;
  height: 53px;
  position: relative;
  font-size: var(--font-size-base);
  line-height: 22px;
  font-weight: 300;
  display: flex;
  align-items: center;
  flex-shrink: 0;
`;
const FrameContainer = styled.div`
  width: 854px;
  border-radius: var(--br-3xs);
  border: 2px solid var(--primary-100);
  box-sizing: border-box;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-2xl) var(--padding-7xl) var(--padding-base);
  gap: var(--gap-5xl);
`;
const TypcnplusIcon1 = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const HowCanIGetStartedWithRewGroup = styled.div`
  width: 854px;
  border-radius: var(--br-3xs);
  border: 2px solid var(--primary-100);
  box-sizing: border-box;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  padding: var(--padding-2xl) var(--padding-12xl) var(--padding-2xl)
    var(--padding-8xl);
  gap: var(--gap-xl);
`;
const HowCanIGetStartedWithRewContainer = styled.div`
  width: 854px;
  border-radius: var(--br-3xs);
  border: 2px solid var(--primary-100);
  box-sizing: border-box;
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  padding: var(--padding-2xl) var(--padding-13xl) var(--padding-2xl)
    var(--padding-9xl);
  gap: var(--gap-xl);
`;
const FrameGroup = styled.div`
  width: 854px;
  overflow-x: auto;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-lg);
  color: var(--black);
  font-family: var(--font-poppins);
`;
const Hero = styled.div`
  flex: 1;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-88xl) var(--padding-xl) var(--padding-139xl);
  box-sizing: border-box;
  gap: var(--gap-55xl);
  max-width: 100%;
  @media screen and (max-width: 1400px) {
    padding-top: var(--padding-51xl);
    padding-bottom: var(--padding-84xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 1125px) {
    gap: 37px 74px;
  }
  @media screen and (max-width: 825px) {
    padding-top: var(--padding-26xl);
    padding-bottom: var(--padding-48xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 18px 74px;
  }
`;
const CalendarPickerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-311xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--font-size-23xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-semibold);
  @media screen and (max-width: 1400px) {
    padding-bottom: var(--padding-195xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 825px) {
    padding-bottom: var(--padding-120xl);
    box-sizing: border-box;
  }
`;

const CalendarPicker = () => {
  return (
    <CalendarPickerRoot>
      <Hero>
        <HeroInner>
          <FrameParent>
            <FrequentlyAskedQuestionsWrapper>
              <FrequentlyAskedQuestionsContainer>
                <FrequentlyAsked>{`Frequently asked `}</FrequentlyAsked>
                <Questions>Questions</Questions>
              </FrequentlyAskedQuestionsContainer>
            </FrequentlyAskedQuestionsWrapper>
            <WeHaveCompiled>
              We have Compiled the most commonly asked question about our
              Platform for your information and to enhance your overall
              experience.
            </WeHaveCompiled>
          </FrameParent>
        </HeroInner>
        <FrameGroup>
          <FrameContainer>
            <HowCanIGetStartedWithRewParent>
              <HowCanI>How can I Get started with Rework AI?</HowCanI>
              <TypcnplusWrapper>
                <TypcnplusIcon alt="" src="/typcnplus.svg" />
              </TypcnplusWrapper>
            </HowCanIGetStartedWithRewParent>
            <LoremIpsumDolor>
              Lorem ipsum dolor sit amet consectetur. Porta velit ultricies
              feugiat tortor odio. Scelerisque habitant quam pharetra adipiscing
              id ipsum et lectus malesuada.
            </LoremIpsumDolor>
          </FrameContainer>
          <HowCanIGetStartedWithRewGroup>
            <HowCanI>How can I Get started with Rework AI?</HowCanI>
            <TypcnplusIcon1 alt="" src="/typcnplus.svg" />
          </HowCanIGetStartedWithRewGroup>
          <HowCanIGetStartedWithRewContainer>
            <HowCanI>How can I Get started with Rework AI?</HowCanI>
            <TypcnplusIcon1 alt="" src="/typcnplus.svg" />
          </HowCanIGetStartedWithRewContainer>
          <HowCanIGetStartedWithRewGroup>
            <HowCanI>How can I Get started with Rework AI?</HowCanI>
            <TypcnplusIcon1 alt="" src="/typcnplus.svg" />
          </HowCanIGetStartedWithRewGroup>
          <HowCanIGetStartedWithRewGroup>
            <HowCanI>How can I Get started with Rework AI?</HowCanI>
            <TypcnplusIcon1 alt="" src="/typcnplus.svg" />
          </HowCanIGetStartedWithRewGroup>
          <HowCanIGetStartedWithRewGroup>
            <HowCanI>How can I Get started with Rework AI?</HowCanI>
            <TypcnplusIcon1 alt="" src="/typcnplus.svg" />
          </HowCanIGetStartedWithRewGroup>
          <HowCanIGetStartedWithRewGroup>
            <HowCanI>How can I Get started with Rework AI?</HowCanI>
            <TypcnplusIcon1 alt="" src="/typcnplus.svg" />
          </HowCanIGetStartedWithRewGroup>
          <HowCanIGetStartedWithRewGroup>
            <HowCanI>How can I Get started with Rework AI?</HowCanI>
            <TypcnplusIcon1 alt="" src="/typcnplus.svg" />
          </HowCanIGetStartedWithRewGroup>
        </FrameGroup>
      </Hero>
    </CalendarPickerRoot>
  );
};

export default CalendarPicker;
