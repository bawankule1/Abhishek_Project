import styled from "styled-components";

const Unsplashmpdlxiig0p0Icon = styled.img`
  align-self: stretch;
  height: 245px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const ReworkHasBeen = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 27px;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
    line-height: 22px;
  }
`;
const WeveBeenAble = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-lg);
  line-height: 27px;
  font-family: var(--font-poppins);
  color: var(--neutrals-300);
`;
const ReworkHasBeenAGreatWayToParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  padding: var(--padding-xl);
  gap: var(--gap-11xl);
`;
const ComponentRoot = styled.div`
  border-radius: var(--br-base);
  background-color: var(--neutrals-white);
  box-shadow: 0px 2px 20px rgba(0, 0, 0, 0.13);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-3xs);
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-4xl);
  color: var(--color-gray-200);
  font-family: var(--font-garnett-medium);
`;

const Component = ({ unsplashMpdLxiIg0P0 }) => {
  return (
    <ComponentRoot>
      <Unsplashmpdlxiig0p0Icon
        loading="lazy"
        alt=""
        src={unsplashMpdLxiIg0P0}
      />
      <ReworkHasBeenAGreatWayToParent>
        <ReworkHasBeen>
          Rework has been a great way to make the hiring process easier and
          faster.
        </ReworkHasBeen>
        <WeveBeenAble>
          “We've been able to save money and time, and the recruiters have been
          able to find the best employers leads. Highly recommend! “
        </WeveBeenAble>
      </ReworkHasBeenAGreatWayToParent>
    </ComponentRoot>
  );
};

export default Component;
