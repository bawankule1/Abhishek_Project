import styled from "styled-components";

const Microsoft1Icon = styled.img`
  align-self: stretch;
  height: 26px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
`;
const Microsoft1Wrapper = styled.div`
  margin-left: -211px;
  width: 131px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px var(--padding-5xs);
  box-sizing: border-box;
`;
const Google20151Icon = styled.img`
  align-self: stretch;
  height: 31px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
`;
const Label = styled.div`
  width: 99px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px var(--padding-7xs-5);
  box-sizing: border-box;
`;
const KisspngAmazonComLogoBrandIcon = styled.img`
  align-self: stretch;
  height: 38px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Label1 = styled.div`
  width: 106px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px var(--padding-11xs);
  box-sizing: border-box;
`;
const HireFor = styled.div`
  width: 312px;
  position: relative;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-base);
  }
`;
const InputFilter = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl);
`;
const KisspngNokiaNetworksLogoNyIcon = styled.img`
  align-self: stretch;
  height: 26px;
  position: relative;
  max-width: 100%;
  overflow: hidden;
  flex-shrink: 0;
  object-fit: cover;
`;
const Label2 = styled.div`
  width: 131px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px 0px;
  box-sizing: border-box;
`;
const VectorIcon = styled.img`
  height: 42px;
  width: 140px;
  position: relative;
`;
const LabelParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--gap-xl);
  @media screen and (max-width: 825px) {
    flex-wrap: wrap;
    justify-content: center;
  }
`;
const DataAggregator = styled.div`
  width: 562px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-11xl);
  max-width: 100%;
`;
const Label3 = styled.div`
  width: 131px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px var(--padding-5xs);
  box-sizing: border-box;
`;
const ThrowStatementRoot = styled.div`
  align-self: stretch;
  background-color: var(--primary-300);
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  padding: var(--padding-31xl) var(--padding-54xl-5);
  box-sizing: border-box;
  gap: var(--gap-61xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--font-size-xl);
  color: var(--color-plum);
  font-family: var(--font-poppins);
  @media screen and (max-width: 1400px) {
    flex-wrap: wrap;
    padding-left: var(--padding-17xl);
    padding-right: var(--padding-17xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 825px) {
    gap: 80px 40px;
  }
  @media screen and (max-width: 450px) {
    gap: 80px 20px;
  }
`;

const ThrowStatement = () => {
  return (
    <ThrowStatementRoot>
      <Microsoft1Wrapper>
        <Microsoft1Icon loading="lazy" alt="" src="/microsoft-1.svg" />
      </Microsoft1Wrapper>
      <Label>
        <Google20151Icon alt="" src="/google2015-1.svg" />
      </Label>
      <Label1>
        <KisspngAmazonComLogoBrandIcon
          loading="lazy"
          alt=""
          src="/kisspngamazoncomlogobrandamazonprimevideoproductamazonoffersboatbassheads225inearsuperex5b816a4424cdd5-1@2x.png"
        />
      </Label1>
      <DataAggregator>
        <InputFilter>
          <HireFor>Hire for 1000+ Brands Including</HireFor>
        </InputFilter>
        <LabelParent>
          <Label2>
            <KisspngNokiaNetworksLogoNyIcon
              loading="lazy"
              alt=""
              src="/kisspngnokianetworkslogonysenokbusiness5b3983e37d3eb2-1@2x.png"
            />
          </Label2>
          <VectorIcon alt="" src="/vector-6.svg" />
          <Label2>
            <Microsoft1Icon loading="lazy" alt="" src="/microsoft-1.svg" />
          </Label2>
        </LabelParent>
      </DataAggregator>
      <Label>
        <Google20151Icon alt="" src="/google2015-1.svg" />
      </Label>
      <Label1>
        <KisspngAmazonComLogoBrandIcon
          loading="lazy"
          alt=""
          src="/kisspngamazoncomlogobrandamazonprimevideoproductamazonoffersboatbassheads225inearsuperex5b816a4424cdd5-1@2x.png"
        />
      </Label1>
      <Label3>
        <KisspngNokiaNetworksLogoNyIcon
          loading="lazy"
          alt=""
          src="/kisspngnokianetworkslogonysenokbusiness5b3983e37d3eb2-2@2x.png"
        />
      </Label3>
    </ThrowStatementRoot>
  );
};

export default ThrowStatement;
