import styled from "styled-components";
import Steps from "./Steps";

const VectorIcon = styled.img`
  height: 25px;
  width: 25px;
  position: absolute;
  margin: 0 !important;
  top: 105px;
  left: 505px;
`;
const HowOurSystem = styled.span``;
const Operates = styled.span`
  font-family: var(--font-garnett-regular);
`;
const HowOurSystemContainer = styled.h1`
  margin: 0;
  width: 658px;
  position: relative;
  font-size: inherit;
  line-height: 50px;
  text-transform: capitalize;
  display: inline-block;
  flex-shrink: 0;
  max-width: 100%;
  font-family: inherit;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-11xl);
    line-height: 40px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-4xl);
    line-height: 30px;
  }
`;
const HowOurSystemOperatesWrapper = styled.div`
  width: 1198px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  max-width: 100%;
`;
const SignUp = styled.div`
  width: 339.3px;
  position: relative;
  line-height: 28px;
  display: inline-block;
  white-space: nowrap;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
    line-height: 22px;
  }
`;
const FollowTheLink = styled.div`
  width: 339.3px;
  height: 100px;
  position: relative;
  font-size: var(--font-size-lg);
  font-family: var(--font-poppins);
  color: var(--color-dimgray-100);
  display: inline-block;
  flex-shrink: 0;
  max-width: 100%;
`;
const MingcuteuserAddLineIcon = styled.img`
  width: 100%;
  height: 100%;
  overflow: hidden;
  flex-shrink: 0;
  z-index: 1;
  object-fit: contain;
  position: absolute;
  left: 0px;
  top: -4px;
  transform: scale(1.333);
`;
const WrapperMingcuteuserAddLine = styled.div`
  width: 84px;
  height: 84px;
  position: absolute;
  margin: 0 !important;
  right: -0.4px;
  bottom: 0px;
  border-radius: var(--br-3xs) 0px 0px 0px;
  flex-shrink: 0;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
`;
const Steps1 = styled.div`
  flex: 1;
  background-color: var(--primary-300);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  padding: var(--padding-11xl) 0px 0px var(--padding-11xl);
  box-sizing: border-box;
  position: relative;
  min-width: 299px;
  min-height: 282px;
  max-width: 100%;
  color: var(--black);
  font-family: var(--font-garnett-semibold);
`;
const StepsParent = styled.div`
  align-self: stretch;
  border-radius: var(--br-5xs);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  max-width: 100%;
  row-gap: 20px;
`;
const GetStarted = styled.div`
  width: 104px;
  position: relative;
  font-weight: 500;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  min-width: 104px;
  white-space: nowrap;
`;
const VectorIcon1 = styled.img`
  height: 0px;
  width: 18px;
  position: relative;
`;
const VectorIcon2 = styled.img`
  height: 14px;
  width: 7px;
  position: relative;
  margin-left: -5px;
`;
const Arrow = styled.div`
  width: 1px;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const SimpleButton = styled.div`
  width: 164px;
  border-radius: var(--br-3xs);
  background-color: var(--white);
  box-shadow: 0px 8px 40px rgba(0, 0, 0, 0.22);
  border: 2px solid var(--primary-100);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) var(--padding-9xl);
  gap: var(--gap-base);
`;
const SimpleButtonWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl);
  text-align: center;
  font-size: var(--font-size-lg);
  color: var(--primary-100);
`;
const FrameParent = styled.div`
  width: 1198px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-70xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-3xl);
  color: var(--color-black);
  font-family: var(--font-poppins);
  @media screen and (max-width: 1400px) {
    gap: 44px 89px;
  }
  @media screen and (max-width: 825px) {
    gap: 22px 89px;
  }
`;
const Steps2 = styled.div`
  flex: 1;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-76xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-95xl);
  max-width: 100%;
  z-index: 1;
  @media screen and (max-width: 825px) {
    gap: 57px 114px;
    padding-top: var(--padding-43xl);
    padding-bottom: var(--padding-43xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 28px 114px;
    padding-top: var(--padding-21xl);
    padding-bottom: var(--padding-21xl);
    box-sizing: border-box;
  }
`;
const VectorParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
  max-width: 100%;
`;
const ForEmployersInnerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-48xl) var(--padding-11xs);
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--font-size-19xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-semibold);
  @media screen and (max-width: 1125px) {
    padding-bottom: var(--padding-25xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-bottom: var(--padding-10xl);
    box-sizing: border-box;
  }
`;

const FrameComponent3 = () => {
  return (
    <ForEmployersInnerRoot>
      <VectorParent>
        <VectorIcon alt="" src="/vector-13.svg" />
        <Steps2>
          <HowOurSystemOperatesWrapper>
            <HowOurSystemContainer>
              <HowOurSystem>{`How Our System `}</HowOurSystem>
              <Operates>Operates</Operates>
            </HowOurSystemContainer>
          </HowOurSystemOperatesWrapper>
          <FrameParent>
            <StepsParent>
              <Steps
                uploadDocuments="Upload Documents"
                shortlistTheMostQualified="Shortlist the most qualified candidate and upload their details for the top companies"
                frame48095633="/frame-48095633.svg"
              />
              <Steps1>
                <SignUp>Sign Up</SignUp>
                <FollowTheLink>
                  Follow the link below to sign up and get access of the current
                  job postings
                </FollowTheLink>
                <WrapperMingcuteuserAddLine>
                  <MingcuteuserAddLineIcon
                    loading="lazy"
                    alt=""
                    src="/mingcuteuseraddline.svg"
                  />
                </WrapperMingcuteuserAddLine>
              </Steps1>
              <Steps
                uploadDocuments="Get Rewards"
                shortlistTheMostQualified="As soon as the candidate gets selected you get your benefits"
                frame48095633="/frame-48095633-1.svg"
                propPadding="0px 0px var(--padding-41xl) var(--padding-11xl)"
                propPadding1="0px var(--padding-mini)"
                propMinHeight="100px"
              />
            </StepsParent>
            <SimpleButtonWrapper>
              <SimpleButton>
                <GetStarted>Get Started</GetStarted>
                <Arrow>
                  <VectorIcon1 alt="" src="/vector.svg" />
                  <VectorIcon2 alt="" src="/vector-1.svg" />
                </Arrow>
              </SimpleButton>
            </SimpleButtonWrapper>
          </FrameParent>
        </Steps2>
      </VectorParent>
    </ForEmployersInnerRoot>
  );
};

export default FrameComponent3;
