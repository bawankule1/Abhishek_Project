import { Button } from "@mui/material";
import styled from "styled-components";

const LogoChild = styled.div`
  height: 100%;
  width: 96.8px;
  position: absolute;
  margin: 0 !important;
  top: 0px;
  right: -0.3px;
  bottom: 0px;
  border-radius: 0px 5.71px 0px 0px;
  background-color: var(--primary-100);
`;
const LogoItem = styled.div`
  height: 100%;
  width: 117.8px;
  position: absolute;
  margin: 0 !important;
  top: 0px;
  bottom: 0px;
  left: 0px;
  border-radius: 5.71px;
  border: 1.4px solid var(--primary-100);
  box-sizing: border-box;
  z-index: 1;
`;
const R = styled.span`
  letter-spacing: -0.02em;
`;
const E = styled.span`
  letter-spacing: 0.08em;
`;
const Re = styled.span`
  font-weight: 600;
`;
const Work = styled.span`
  letter-spacing: -0.02em;
  font-family: var(--font-actor);
  color: var(--color-white);
`;
const Rework = styled.div`
  height: 24px;
  position: relative;
  display: inline-block;
  min-width: 107.1px;
  white-space: nowrap;
  z-index: 2;
`;
const Ai = styled.div`
  height: 8px;
  position: relative;
  display: inline-block;
  min-width: 10px;
  z-index: 1;
`;
const ControlFlow = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-base) 0px 0px;
  font-size: var(--font-size-xs-4);
  color: var(--color-white);
  font-family: var(--font-gilroy-regular);
`;
const Logo = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) var(--padding-6xs) var(--padding-5xs)
    var(--padding-5xs-8);
  position: relative;
  gap: var(--gap-5xs-1);
`;
const FunctionUnit = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px var(--padding-11xs);
  text-align: left;
  font-family: var(--font-outfit);
`;
const TalentFinder = styled.div`
  width: 103px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 103px;
  white-space: nowrap;
`;
const ForRecruiters = styled.div`
  flex: 1;
  position: relative;
  display: inline-block;
  min-width: 109px;
  white-space: nowrap;
`;
const ForEmployers = styled.div`
  align-self: stretch;
  position: relative;
  font-weight: 600;
  display: inline-block;
  min-width: 115px;
  white-space: nowrap;
`;
const IfStatementIcon = styled.img`
  height: 3px;
  width: 37px;
  position: relative;
`;
const IfStatementWrapper = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-20xl);
`;
const ForEmployersParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-12xs);
  color: var(--primary-100);
`;
const AboutUs = styled.div`
  width: 72px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 72px;
  white-space: nowrap;
`;
const Company = styled.div`
  width: 80px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 80px;
`;
const Subroutine = styled.div`
  width: 607px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-13xl);
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    display: none;
  }
  @media screen and (max-width: 825px) {
    gap: 32px 16px;
  }
`;
const SubroutineWrapper = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px 0px var(--padding-7xs);
  box-sizing: border-box;
  max-width: 100%;
  font-size: var(--font-size-base);
  color: var(--color-gray-100);
`;
const LogIn = styled.div`
  width: 53px;
  position: relative;
  font-weight: 500;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  min-width: 53px;
  white-space: nowrap;
`;
const VectorIcon = styled.img`
  height: 0px;
  width: 18px;
  position: relative;
`;
const VectorIcon1 = styled.img`
  height: 14px;
  width: 7px;
  position: relative;
  margin-left: -5px;
`;
const Arrow = styled.div`
  width: 1px;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const SimpleButton = styled.div`
  width: 129px;
  border-radius: var(--br-3xs);
  border: 2px solid var(--primary-100);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-4xs-5) var(--padding-17xl);
  gap: var(--gap-base);
`;
const GetStarted = styled.div`
  width: 104px;
  position: relative;
  font-weight: 500;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  min-width: 104px;
  white-space: nowrap;
`;
const SimpleButton1 = styled.div`
  border-radius: var(--br-3xs);
  background-color: var(--primary-100);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-4xs-5) var(--padding-5xl);
  gap: var(--gap-base);
  color: var(--color-white);
`;
const ElseBlock = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-mid);
  font-size: var(--font-size-lg);
`;
const OutputPort = styled.header`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-17xl);
  top: 0;
  z-index: 99;
  position: sticky;
  max-width: 100%;
  text-align: center;
  font-size: var(--font-size-16xl-5);
  color: var(--primary-100);
  font-family: var(--font-poppins);
  @media screen and (max-width: 825px) {
    gap: 36px 18px;
  }
`;
const StringOperation = styled.div`
  position: absolute;
  height: 100%;
  top: 0px;
  bottom: 0px;
  left: 174px;
  border-radius: 50%;
  background-color: var(--color-whitesmoke-100);
  width: 596px;
`;
const TreeExplorerChild = styled.div`
  position: absolute;
  top: 0px;
  left: 0px;
  border-radius: var(--br-8xs);
  background-color: var(--primary-100);
  width: 100%;
  height: 100%;
  display: none;
`;
const K = styled.b``;
const K1 = styled.p`
  margin: 0;
`;
const CandidatesHired = styled.p`
  margin: 0;
  font-size: var(--font-size-smi-3);
  font-family: var(--font-garnett-light);
`;
const KCandidatesHiredContainer = styled.div`
  position: absolute;
  top: 22px;
  left: 92px;
  z-index: 1;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
  }
`;
const TryBlock = styled(Button)`
  position: absolute;
  top: 15px;
  left: 16px;
  z-index: 1;
`;
const TreeExplorer = styled.div`
  position: absolute;
  top: 358px;
  left: 0px;
  border-radius: var(--br-8xs);
  background-color: var(--primary-100);
  width: 219px;
  height: 94px;
`;
const ListimageIcon = styled.img`
  position: absolute;
  top: 145px;
  left: 1px;
  border-radius: 0px 0px 0px var(--br-96xl);
  width: 567px;
  height: 402px;
  object-fit: cover;
  z-index: 4;
`;
const DijkstraAlgorithm = styled.div`
  position: absolute;
  height: 100%;
  top: 0px;
  bottom: 0px;
  left: 174px;
  width: 568px;
`;
const MaskGroup = styled.div`
  position: absolute;
  top: 0px;
  left: 0px;
  width: 100%;
  height: 555px;
  overflow: hidden;
  z-index: 1;
`;
const StringOperationParent = styled.div`
  height: 596px;
  width: 744px;
  position: absolute;
  margin: 0 !important;
  right: -635px;
  bottom: -370px;
`;
const WithRework = styled.p`
  margin: 0;
  font-size: var(--font-size-29xl);
  font-family: var(--font-garnett-regular);
`;
const PowerUpYourContainer = styled.div`
  height: 141px;
  flex: 1;
  position: relative;
  color: var(--primary-100);
  display: inline-block;
  max-width: 100%;
  z-index: 5;
  font-size: var(--font-size-35xl);
  font-family: var(--font-garnett-semibold);
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-19xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-10xl);
  }
`;
const DataFlowGraph = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
  max-width: 100%;
`;
const EmpowerYourBusiness = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-sm);
  line-height: 22px;
  font-family: var(--font-poppins);
  color: var(--black);
  z-index: 5;
`;
const LeafGraph = styled.div`
  width: 685px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-3xs);
  max-width: 100%;
`;
const BookADemo = styled.div`
  position: relative;
  line-height: 28px;
`;
const CtaButton = styled.div`
  border-radius: var(--br-xl);
  background-color: var(--primary-100);
  box-shadow: 0px 8px 18px rgba(174, 93, 255, 0.46);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-2xl) var(--padding-37xl);
  white-space: nowrap;
  @media screen and (max-width: 450px) {
    padding-left: var(--padding-xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const GroupIcon = styled.img`
  height: 20px;
  width: 20px;
  position: relative;
`;
const NoCreditRequired = styled.div`
  position: relative;
`;
const ExportStatement = styled.div`
  border-radius: var(--br-3xs);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) 0px;
  gap: var(--gap-3xs);
`;
const CentroidFinderChild = styled.div`
  height: 94px;
  width: 219px;
  position: relative;
  border-radius: var(--br-8xs);
  background-color: var(--primary-100);
  display: none;
`;
const TryBlockChild = styled.div`
  height: 64px;
  width: 64px;
  position: relative;
  border-radius: var(--br-8xs);
  background-color: var(--primary-300);
  display: none;
`;
const CatchBlockIcon = styled.img`
  height: 28.3px;
  width: 28.3px;
  position: relative;
  z-index: 2;
`;
const TryBlock1 = styled.div`
  border-radius: var(--br-8xs);
  background-color: var(--primary-300);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-lg) var(--padding-lg) var(--padding-mid-7);
  z-index: 1;
`;
const HappyCompanies = styled.div`
  height: 46px;
  position: relative;
  display: inline-block;
  z-index: 1;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
  }
`;
const FinallyBlock = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-8xs) 0px 0px;
`;
const CentroidFinder = styled.div`
  border-radius: var(--br-8xs);
  background-color: var(--primary-100);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-mini) var(--padding-sm) var(--padding-mini)
    var(--padding-base);
  gap: var(--gap-mini);
  z-index: 5;
`;
const DensityCalculator = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  font-size: var(--font-size-5xl-9);
  color: var(--primary-300);
  font-family: var(--font-space-grotesk);
`;
const ImportStatement = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-12xs);
  max-width: 100%;
`;
const Destructor = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px var(--padding-12xs);
  box-sizing: border-box;
  max-width: 100%;
  font-size: var(--font-size-sm);
  color: var(--primary-100);
`;
const MethodDefinition = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-8xl);
  max-width: 100%;
  font-size: var(--font-size-5xl);
  color: var(--white);
  font-family: var(--font-poppins);
`;
const BranchNetwork = styled.div`
  width: 951px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-17xl);
  max-width: 100%;
  @media screen and (max-width: 825px) {
    gap: 18px 36px;
  }
`;
const InputLinkChild = styled.div`
  width: 140px;
  height: 41px;
  position: relative;
  display: none;
`;
const InputLinkRoot = styled.div`
  align-self: stretch;
  background-color: var(--white);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-15xl) var(--padding-101xl) var(--padding-19xl);
  box-sizing: border-box;
  gap: var(--gap-85xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-5xl-9);
  color: var(--primary-300);
  font-family: var(--font-space-grotesk);
  @media screen and (max-width: 825px) {
    gap: 52px 104px;
    padding: var(--padding-3xl) var(--padding-41xl) var(--padding-6xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 26px 104px;
    padding-left: var(--padding-xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;

const InputLink = () => {
  return (
    <InputLinkRoot>
      <OutputPort>
        <FunctionUnit>
          <Logo>
            <LogoChild />
            <LogoItem />
            <Rework>
              <Re>
                <R>r</R>
                <E>e</E>
              </Re>
              <Work>work</Work>
            </Rework>
            <ControlFlow>
              <Ai>ai</Ai>
            </ControlFlow>
          </Logo>
        </FunctionUnit>
        <SubroutineWrapper>
          <Subroutine>
            <TalentFinder>Talent Finder</TalentFinder>
            <ForRecruiters>For Recruiters</ForRecruiters>
            <ForEmployersParent>
              <ForEmployers>For Employers</ForEmployers>
              <IfStatementWrapper>
                <IfStatementIcon alt="" src="/if-statement.svg" />
              </IfStatementWrapper>
            </ForEmployersParent>
            <AboutUs>About Us</AboutUs>
            <Company>Company</Company>
          </Subroutine>
        </SubroutineWrapper>
        <ElseBlock>
          <SimpleButton>
            <LogIn>Log In</LogIn>
            <Arrow>
              <VectorIcon alt="" src="/vector.svg" />
              <VectorIcon1 alt="" src="/vector-1.svg" />
            </Arrow>
          </SimpleButton>
          <SimpleButton1>
            <GetStarted>Get Started</GetStarted>
            <Arrow>
              <VectorIcon alt="" src="/vector.svg" />
              <VectorIcon1 alt="" src="/vector-1.svg" />
            </Arrow>
          </SimpleButton1>
        </ElseBlock>
      </OutputPort>
      <BranchNetwork>
        <LeafGraph>
          <DataFlowGraph>
            <StringOperationParent>
              <StringOperation />
              <MaskGroup>
                <TreeExplorer>
                  <TreeExplorerChild />
                  <KCandidatesHiredContainer>
                    <K1>
                      <K>+10K</K>
                    </K1>
                    <CandidatesHired>Candidates Hired</CandidatesHired>
                  </KCandidatesHiredContainer>
                  <TryBlock
                    disableElevation={true}
                    color="primary"
                    variant="outlined"
                    sx={{
                      borderRadius: "0px 0px 0px 0px",
                      width: 64,
                      height: 64,
                    }}
                  />
                </TreeExplorer>
                <DijkstraAlgorithm>
                  <ListimageIcon alt="" src="/listimage@2x.png" />
                </DijkstraAlgorithm>
              </MaskGroup>
            </StringOperationParent>
            <PowerUpYourContainer>
              <K1>Power Up Your Hiring</K1>
              <WithRework>with Rework .</WithRework>
            </PowerUpYourContainer>
          </DataFlowGraph>
          <EmpowerYourBusiness>{`Empower your business with cutting-edge A.I. technology, simplified processes, and top-tier talent connections. Rework is your strategic partner in redefining how you hire `}</EmpowerYourBusiness>
        </LeafGraph>
        <MethodDefinition>
          <CtaButton>
            <BookADemo>Book A Demo</BookADemo>
          </CtaButton>
          <Destructor>
            <ImportStatement>
              <ExportStatement>
                <GroupIcon alt="" src="/group.svg" />
                <NoCreditRequired>No credit Required</NoCreditRequired>
              </ExportStatement>
              <ExportStatement>
                <GroupIcon alt="" src="/group.svg" />
                <NoCreditRequired>
                  Streamlined Recruitment Process
                </NoCreditRequired>
              </ExportStatement>
              <DensityCalculator>
                <CentroidFinder>
                  <CentroidFinderChild />
                  <TryBlock1>
                    <TryBlockChild />
                    <CatchBlockIcon alt="" src="/vector-5.svg" />
                  </TryBlock1>
                  <FinallyBlock>
                    <HappyCompanies>
                      <K1>
                        <K>+360</K>
                      </K1>
                      <CandidatesHired>Happy Companies</CandidatesHired>
                    </HappyCompanies>
                  </FinallyBlock>
                </CentroidFinder>
              </DensityCalculator>
            </ImportStatement>
          </Destructor>
        </MethodDefinition>
      </BranchNetwork>
      <InputLinkChild />
    </InputLinkRoot>
  );
};

export default InputLink;
