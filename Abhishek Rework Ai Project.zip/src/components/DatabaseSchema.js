import styled from "styled-components";
import Component from "./Component";

const Success = styled.span``;
const Stories = styled.span`
  font-family: var(--font-garnett-regular);
`;
const SuccessStories = styled.h1`
  margin: 0;
  height: 59px;
  width: 341px;
  position: relative;
  font-size: inherit;
  text-transform: capitalize;
  display: inline-block;
  max-width: 100%;
  font-family: inherit;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-15xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
  }
`;
const BooleanOperator = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl) 0px var(--padding-2xl);
  box-sizing: border-box;
  max-width: 100%;
`;
const Component11Parent = styled.div`
  align-self: stretch;
  display: grid;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-xl);
  max-width: 100%;
  grid-template-columns: repeat(3, minmax(288px, 1fr));
  font-size: var(--font-size-4xl);
  color: var(--color-gray-200);
  font-family: var(--font-garnett-medium);
  @media screen and (max-width: 1125px) {
    justify-content: center;
    grid-template-columns: repeat(2, minmax(288px, 499px));
  }
  @media screen and (max-width: 825px) {
    grid-template-columns: minmax(288px, 1fr);
  }
`;
const DataAggregator = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-33xl);
  max-width: 100%;
  @media screen and (max-width: 825px) {
    gap: 26px 52px;
  }
`;
const FrameChild = styled.div`
  height: 8px;
  width: 34px;
  position: relative;
  border-radius: var(--br-8xs);
  background-color: var(--primary-100);
  overflow: hidden;
  flex-shrink: 0;
`;
const FrameItem = styled.div`
  height: 8px;
  flex: 1;
  position: relative;
  border-radius: var(--br-8xs);
  background-color: var(--primary-300);
  overflow: hidden;
`;
const FrameParent = styled.div`
  width: 128px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-smi);
`;
const FrameWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl) 0px var(--padding-3xl);
`;
const DataAggregatorParent = styled.div`
  width: 1192px;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  gap: var(--gap-24xl);
  max-width: 100%;
  @media screen and (max-width: 825px) {
    gap: 21px 43px;
  }
`;
const DatabaseSchemaRoot = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-3xl) 0px var(--padding-xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-23xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-semibold);
`;

const DatabaseSchema = () => {
  return (
    <DatabaseSchemaRoot>
      <DataAggregatorParent>
        <DataAggregator>
          <BooleanOperator>
            <SuccessStories>
              <Success>{`Success `}</Success>
              <Stories>Stories</Stories>
            </SuccessStories>
          </BooleanOperator>
          <Component11Parent>
            <Component unsplashMpdLxiIg0P0="/unsplashmpdlxiig0p0@2x.png" />
            <Component unsplashMpdLxiIg0P0="/unsplashmpdlxiig0p0-1@2x.png" />
            <Component unsplashMpdLxiIg0P0="/unsplashmpdlxiig0p0-2@2x.png" />
          </Component11Parent>
        </DataAggregator>
        <FrameWrapper>
          <FrameParent>
            <FrameChild />
            <FrameItem />
          </FrameParent>
        </FrameWrapper>
      </DataAggregatorParent>
    </DatabaseSchemaRoot>
  );
};

export default DatabaseSchema;
