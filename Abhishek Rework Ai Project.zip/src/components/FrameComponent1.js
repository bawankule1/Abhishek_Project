import styled from "styled-components";
import Component1 from "./Component1";

const Customer = styled.span``;
const Testimonials = styled.span`
  font-family: var(--font-garnett-regular);
  color: var(--color-gray-500);
`;
const CustomerTestimonials = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 59px;
  position: relative;
  font-size: inherit;
  display: inline-block;
  font-family: inherit;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-15xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
  }
`;
const WhatOthersHas = styled.div`
  position: relative;
  font-size: var(--font-size-lg);
  font-family: var(--font-poppins);
  color: var(--color-gray-500);
`;
const CustomerTestimonialsParent = styled.div`
  width: 496px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-11xs);
  max-width: 100%;
`;
const Component16Parent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-11xl);
  min-width: 287px;
  max-width: 100%;
`;
const FrameGroup = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-5xl);
  max-width: 100%;
  font-size: var(--font-size-lg);
  color: var(--color-black);
  font-family: var(--font-poppins);
`;
const FrameParent = styled.div`
  width: 1198px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-67xl);
  max-width: 100%;
  @media screen and (max-width: 1400px) {
    gap: 43px 86px;
  }
  @media screen and (max-width: 825px) {
    gap: 21px 86px;
  }
`;
const ForEmployersInnerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl) var(--padding-194xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-23xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-semibold);
  @media screen and (max-width: 1125px) {
    padding-bottom: var(--padding-119xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 825px) {
    padding-bottom: var(--padding-71xl);
    box-sizing: border-box;
  }
`;

const FrameComponent1 = () => {
  return (
    <ForEmployersInnerRoot>
      <FrameParent>
        <CustomerTestimonialsParent>
          <CustomerTestimonials>
            <Customer>{`Customer `}</Customer>
            <Testimonials>Testimonials</Testimonials>
          </CustomerTestimonials>
          <WhatOthersHas>What others has say About Us</WhatOthersHas>
        </CustomerTestimonialsParent>
        <FrameGroup>
          <Component16Parent>
            <Component1
              reworkHasBeenAGreatWayToM="“Rework has been a great way to make the hiring process easier and faster. We've been able to save money and time, and the recruiters have been able to find the best employers leads. Highly recommend! “"
              ellipse2="/ellipse-2@2x.png"
              theresaWebb="Theresa Webb"
              hRManagerAmazon="HR Manager, Amazon"
            />
            <Component1
              reworkHasBeenAGreatWayToM="“ Rework has been a great way to make the hiring process easier and faster. We've been able to save money and time, ““ Rework has been a great way to make the hiring process easier and faster.  Highly recommend! “"
              ellipse2="/ellipse-1@2x.png"
              theresaWebb="Ronald Richards"
              hRManagerAmazon="HR Manager, Google"
            />
          </Component16Parent>
          <Component16Parent>
            <Component1
              reworkHasBeenAGreatWayToM="“Rework has been a great way to make the hiring process easier and faster. We've been able to save money and time, and the recruiters have been able to find the best employers leads. Highly recommend! ““ Rework has been a great way to make the hiring process easier and faster.  Highly recommend! “"
              ellipse2="/ellipse-1-1@2x.png"
              theresaWebb="Savannah Nguyen"
              hRManagerAmazon="HR Manager, Microsoft"
            />
            <Component1
              reworkHasBeenAGreatWayToM="“Rework has been a great way to make the hiring process easier and faster. We've been able to save money and time, and the recruiters have been able to find the best employers leads. Highly recommend! “"
              ellipse2="/ellipse-1-2@2x.png"
              theresaWebb="Ronald Richards"
              hRManagerAmazon="HR Manager, Google"
            />
          </Component16Parent>
          <Component16Parent>
            <Component1
              reworkHasBeenAGreatWayToM="“Rework has been a great way to make the hiring process easier and faster. We've been able to save money and time, and the recruiters have been able to find the best employers leads. Highly recommend! “"
              ellipse2="/ellipse-2-1@2x.png"
              theresaWebb="Theresa Webb"
              hRManagerAmazon="HR Manager, Amazon"
            />
            <Component1
              reworkHasBeenAGreatWayToM="“ Rework has been a great way to make the hiring process easier and faster. We've been able to save money and time, ““ Rework has been a great way to make the hiring process easier and faster.  Highly recommend! “"
              ellipse2="/ellipse-1-3@2x.png"
              theresaWebb="Ronald Richards"
              hRManagerAmazon="HR Manager, Google"
            />
          </Component16Parent>
        </FrameGroup>
      </FrameParent>
    </ForEmployersInnerRoot>
  );
};

export default FrameComponent1;
