import styled from "styled-components";

const HowReworkAi = styled.span``;
const HiringPlatformFor = styled.span`
  font-family: var(--font-garnett-regular);
`;
const HowReworkAiContainer = styled.h1`
  margin: 0;
  align-self: stretch;
  height: 212px;
  position: relative;
  font-size: inherit;
  display: inline-block;
  font-family: inherit;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-11xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-4xl);
  }
`;
const HowReworkAiHasBeenAGoodWrapper = styled.div`
  width: 391px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-3xs) 0px 0px;
  box-sizing: border-box;
  max-width: 100%;
  font-size: var(--font-size-19xl);
  font-family: var(--font-garnett-medium);
`;
const B = styled.b`
  position: relative;
  display: inline-block;
  min-width: 101px;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-21xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-11xl);
  }
`;
const Wrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-51xl) 0px var(--padding-51xl-2);
`;
const ReductionInYour = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-lg);
  font-family: var(--font-poppins);
  color: var(--color-darkslategray);
  text-align: center;
`;
const FrameContainer = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-3xs);
  min-width: 157px;
`;
const FrameChild = styled.div`
  height: 184px;
  width: 2px;
  position: relative;
  border-right: 2px solid var(--primary-100);
  box-sizing: border-box;
  @media screen and (max-width: 825px) {
    width: 100%;
    height: 2px;
  }
`;
const FrameGroup = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-mid-4);
  @media screen and (max-width: 825px) {
    flex-wrap: wrap;
  }
`;
const FrameWrapper = styled.div`
  width: 538.7px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-3xl) 0px 0px;
  box-sizing: border-box;
  max-width: 100%;
`;
const K = styled.b`
  position: relative;
  display: inline-block;
  min-width: 84px;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-21xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-11xl);
  }
`;
const KWrapper = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-60xl) 0px var(--padding-59xl-6);
`;
const FrameParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-3xs);
`;
const FrameWrapper1 = styled.div`
  width: 241.3px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-3xl) 0px 0px;
  box-sizing: border-box;
`;
const FrameParentRoot = styled.div`
  align-self: stretch;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-76xl) var(--padding-xl) var(--padding-76xl)
    var(--padding-2xl);
  box-sizing: border-box;
  gap: var(--gap-base);
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-31xl);
  color: var(--primary-100);
  font-family: var(--font-space-grotesk);
  @media screen and (max-width: 1400px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 450px) {
    padding-top: var(--padding-43xl);
    padding-bottom: var(--padding-43xl);
    box-sizing: border-box;
  }
`;

const FrameComponent = () => {
  return (
    <FrameParentRoot>
      <HowReworkAiHasBeenAGoodWrapper>
        <HowReworkAiContainer>
          <HowReworkAi>{`How Rework AI has been a good `}</HowReworkAi>
          <HiringPlatformFor>Hiring platform for Companies</HiringPlatformFor>
        </HowReworkAiContainer>
      </HowReworkAiHasBeenAGoodWrapper>
      <FrameWrapper>
        <FrameGroup>
          <FrameContainer>
            <Wrapper>
              <B>80%</B>
            </Wrapper>
            <ReductionInYour>
              Reduction in your recruitment TAT with the access to a wider
              talent pool on the platform
            </ReductionInYour>
          </FrameContainer>
          <FrameChild />
          <FrameContainer>
            <Wrapper>
              <B>50%</B>
            </Wrapper>
            <ReductionInYour>
              Streamline your budgeting and save money while finding the top
              candidates
            </ReductionInYour>
          </FrameContainer>
          <FrameChild />
        </FrameGroup>
      </FrameWrapper>
      <FrameWrapper1>
        <FrameParent>
          <KWrapper>
            <K>10k</K>
          </KWrapper>
          <ReductionInYour>
            Certified sourcing partners’ expertise
          </ReductionInYour>
        </FrameParent>
      </FrameWrapper1>
    </FrameParentRoot>
  );
};

export default FrameComponent;
