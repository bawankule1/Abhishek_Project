import styled from "styled-components";

const Div = styled.div`
  align-self: stretch;
  position: relative;
  font-weight: 500;
  display: inline-block;
  min-width: 11px;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
  }
  min-width: ${(p) => p.propMinWidth};
`;
const ValueValidator = styled.div`
  width: 11px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-11xs-5) 0px 0px;
  box-sizing: border-box;
  width: ${(p) => p.propWidth};
`;
const Month = styled.div`
  flex: 1;
  position: relative;
  font-family: var(--font-garnett-medium);
  display: inline-block;
  min-width: 49px;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
  }
  min-width: ${(p) => p.propMinWidth1};
`;
const ValueValidatorParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-8xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const PatternProducer = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-48xl);
  padding: ${(p) => p.propPadding1};
`;
const H = styled.h1`
  margin: 0;
  height: 56px;
  width: 26px;
  position: relative;
  font-size: inherit;
  font-weight: 500;
  font-family: var(--font-space-grotesk);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  min-width: 26px;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-13xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-5xl);
  }
`;
const DataMerger = styled.div`
  height: 56px;
  flex: 1;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 90px;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-13xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-5xl);
  }
`;
const Month1 = styled.div`
  height: 38px;
  width: 61px;
  position: relative;
  font-size: var(--font-size-base);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  min-width: 61px;
`;
const ColorPicker = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  row-gap: 20px;
  font-size: var(--font-size-21xl);
  color: var(--color-gray-300);
  font-family: var(--font-garnett-medium);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const PatternProducerParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
`;
const Positioner = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-17xl) 0px var(--padding-16xl);
  font-size: var(--font-size-4xl);
  padding: ${(p) => p.propPadding};
`;
const SuitableForCompanies = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 28px;
`;
const Icons = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const InterviewReadyCandidates = styled.div`
  flex: 1;
  position: relative;
`;
const ValueChecker = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-3xs);
`;
const Icons1 = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ReceivePreVettedProfiles = styled.div`
  flex: 1;
  position: relative;
  display: inline-block;
  min-width: 170px;
`;
const ValueTransformer = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-3xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const AssistanceWithInterview = styled.div`
  flex: 1;
  position: relative;
  display: inline-block;
  min-width: 159px;
`;
const ShapeCombiner = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--gap-3xs);
  text-align: left;
  font-size: var(--font-size-base);
  color: var(--color-dimgray-100);
  font-family: var(--font-poppins);
`;
const DataFilter = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--gap-xl);
`;
const DataFilterWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-lgi);
  font-family: var(--font-garnett-medium);
`;
const GetStarted = styled.div`
  width: 103px;
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  min-width: 103px;
  white-space: nowrap;
`;
const VectorIcon = styled.img`
  height: 0px;
  width: 18px;
  position: relative;
`;
const VectorIcon1 = styled.img`
  height: 14px;
  width: 7px;
  position: relative;
  margin-left: -5px;
`;
const Arrow = styled.div`
  width: 1px;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const SimpleButton = styled.div`
  flex: 1;
  border-radius: var(--br-3xs);
  background-color: var(--primary-100);
  box-shadow: 0px 20px 40px rgba(92, 39, 192, 0.35);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-base) var(--padding-xl);
  gap: var(--gap-base);
`;
const SimpleButtonWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px 0px var(--padding-12xs);
  color: var(--color-white);
  font-family: var(--font-poppins);
`;
const SizeAdjusterRoot = styled.div`
  flex: 1;
  border-radius: var(--br-3xs);
  background-color: var(--white);
  box-shadow: 0px 20px 40px rgba(118, 118, 118, 0.35);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-15xl) var(--padding-15xl) var(--padding-11xl)
    var(--padding-16xl);
  box-sizing: border-box;
  gap: var(--gap-27xl);
  min-width: 274px;
  max-width: 100%;
  text-align: center;
  font-size: var(--font-size-lg);
  color: var(--primary-100);
  font-family: var(--font-space-grotesk);
  @media screen and (max-width: 825px) {
    padding-top: var(--padding-3xl);
    padding-bottom: var(--padding-xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 23px 46px;
  }
`;

const SizeAdjuster = ({
  prop,
  month,
  dataMerger,
  propPadding,
  propPadding1,
  propWidth,
  propMinWidth,
  propMinWidth1,
}) => {
  return (
    <SizeAdjusterRoot>
      <Positioner propPadding={propPadding}>
        <PatternProducerParent>
          <PatternProducer propPadding1={propPadding1}>
            <ValueValidatorParent>
              <ValueValidator propWidth={propWidth}>
                <Div propMinWidth={propMinWidth}>{prop}</Div>
              </ValueValidator>
              <Month propMinWidth1={propMinWidth1}>{month}</Month>
            </ValueValidatorParent>
          </PatternProducer>
          <ColorPicker>
            <H>₹</H>
            <DataMerger>{dataMerger}</DataMerger>
            <Month1>/month</Month1>
          </ColorPicker>
        </PatternProducerParent>
      </Positioner>
      <DataFilterWrapper>
        <DataFilter>
          <SuitableForCompanies>
            Suitable for companies with 5-10 openings
          </SuitableForCompanies>
          <ShapeCombiner>
            <ValueChecker>
              <Icons loading="lazy" alt="" src="/icons.svg" />
              <InterviewReadyCandidates>
                10 interview-ready candidates
              </InterviewReadyCandidates>
            </ValueChecker>
            <ValueChecker>
              <Icons alt="" src="/icons.svg" />
              <InterviewReadyCandidates>
                Unlimited job postings
              </InterviewReadyCandidates>
            </ValueChecker>
            <ValueTransformer>
              <Icons1 alt="" src="/icons.svg" />
              <ReceivePreVettedProfiles>
                Receive pre-vetted profiles within 48 hours
              </ReceivePreVettedProfiles>
            </ValueTransformer>
            <ValueChecker>
              <Icons alt="" src="/icons-3.svg" />
              <InterviewReadyCandidates>
                Dedicated account manager
              </InterviewReadyCandidates>
            </ValueChecker>
            <ValueTransformer>
              <Icons1 alt="" src="/icons-3.svg" />
              <AssistanceWithInterview>
                Assistance with interview scheduling
              </AssistanceWithInterview>
            </ValueTransformer>
            <ValueChecker>
              <Icons alt="" src="/icons-3.svg" />
              <InterviewReadyCandidates>
                Custom reports
              </InterviewReadyCandidates>
            </ValueChecker>
          </ShapeCombiner>
        </DataFilter>
      </DataFilterWrapper>
      <SimpleButtonWrapper>
        <SimpleButton>
          <GetStarted>Get Started</GetStarted>
          <Arrow>
            <VectorIcon alt="" src="/vector.svg" />
            <VectorIcon1 alt="" src="/vector-1.svg" />
          </Arrow>
        </SimpleButton>
      </SimpleButtonWrapper>
    </SizeAdjusterRoot>
  );
};

export default SizeAdjuster;
