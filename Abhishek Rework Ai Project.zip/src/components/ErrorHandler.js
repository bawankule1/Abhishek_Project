import styled from "styled-components";

const OurAmazingBenefits = styled.span``;
const HelpfulForYour = styled.span`
  font-family: var(--font-garnett-regular);
`;
const OurAmazingBenefitsContainer = styled.h1`
  margin: 0;
  width: 997px;
  position: relative;
  font-size: inherit;
  line-height: 50px;
  text-transform: capitalize;
  display: inline-block;
  flex-shrink: 0;
  max-width: 100%;
  font-family: inherit;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
    line-height: 30px;
  }
`;
const OurAmazingBenefitsHelpfulFWrapper = styled.div`
  width: 1200px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-2xl) 0px var(--padding-xl);
  box-sizing: border-box;
  max-width: 100%;
`;
const FrameChild = styled.div`
  width: 975px;
  display: none;
  max-width: 100%;
`;
const EosIconsai = styled.img`
  width: 50px;
  height: 50px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const P = styled.p`
  margin: 0;
`;
const CostReduce = styled.p`
  margin: 0;
  font-family: var(--font-garnett-regular);
`;
const CostReduce1 = styled.div`
  align-self: stretch;
  height: 66px;
  position: relative;
  display: inline-block;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
  }
`;
const ZeroOverheadIn = styled.div`
  align-self: stretch;
  position: relative;
  font-size: var(--font-size-base);
  line-height: 28px;
  font-family: var(--font-poppins);
  color: var(--color-gray-400);
`;
const EosIconsaiParent = styled.div`
  width: 343.7px;
  margin: 0 !important;
  position: absolute;
  top: 0px;
  left: 0px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-lg);
`;
const FasterRecruitmentByContainer = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 28px;
  display: inline-block;
  min-height: 66px;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
  }
`;
const EosIconsaiGroup = styled.div`
  width: 343.7px;
  margin: 0 !important;
  position: absolute;
  top: 0px;
  left: 428.2px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-lg);
`;
const VectorIcon = styled.img`
  width: 43px;
  height: 32.2px;
  position: relative;
`;
const VectorIcon1 = styled.img`
  width: 66.74%;
  height: 55.59%;
  position: absolute;
  margin: 0 !important;
  top: 21.43%;
  right: 14.65%;
  bottom: 22.98%;
  left: 18.6%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  z-index: 1;
`;
const VectorParent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
  gap: var(--gap-3xs);
`;
const FrameWrapper = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-9xs) 0px var(--padding-9xs-7);
`;
const HighlyContextualizedIntervieParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-lg);
`;
const FrameContainer = styled.div`
  width: 343.7px;
  margin: 0 !important;
  position: absolute;
  top: 0px;
  left: 856.3px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-8xs) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-11xl-8);
`;
const VectorIcon2 = styled.img`
  height: 36px;
  width: 36px;
  position: relative;
`;
const VectorIcon3 = styled.img`
  height: 38.89%;
  width: 61.11%;
  position: absolute;
  margin: 0 !important;
  top: 41.67%;
  right: 27.78%;
  bottom: 19.44%;
  left: 11.11%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  z-index: 1;
`;
const VectorIcon4 = styled.img`
  height: 15.28%;
  width: 8.33%;
  position: absolute;
  margin: 0 !important;
  top: 70.83%;
  right: 13.89%;
  bottom: 13.89%;
  left: 77.78%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  z-index: 1;
`;
const VectorIcon5 = styled.img`
  height: 19.44%;
  width: 33.33%;
  position: absolute;
  margin: 0 !important;
  top: 0%;
  right: 38.89%;
  bottom: 80.56%;
  left: 27.78%;
  max-width: 100%;
  overflow: hidden;
  max-height: 100%;
  z-index: 1;
`;
const VectorGroup = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
  gap: var(--gap-3xs);
`;
const FrameWrapper1 = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-7xs);
`;
const FrameDiv = styled.div`
  width: 343.7px;
  margin: 0 !important;
  position: absolute;
  top: 308px;
  left: 0px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-7xs) 0px 0px;
  box-sizing: border-box;
  gap: var(--gap-5xl);
`;
const EosIconsaiContainer = styled.div`
  width: 343.7px;
  margin: 0 !important;
  position: absolute;
  top: 308px;
  left: 428.2px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-lg);
`;
const FluenttasksApp20RegularParent = styled.div`
  width: 343.7px;
  margin: 0 !important;
  position: absolute;
  top: 308px;
  left: 856.3px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-lg);
`;
const FrameGroup = styled.div`
  width: 1200px;
  height: 544px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  position: relative;
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-5xl);
`;
const FrameParent = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: var(--padding-82xl) var(--padding-xl) var(--padding-136xl);
  box-sizing: border-box;
  gap: var(--gap-74xl);
  max-width: 100%;
  z-index: 2;
  @media screen and (max-width: 1125px) {
    padding-top: var(--padding-47xl);
    padding-bottom: var(--padding-82xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 825px) {
    gap: 46px 93px;
    padding-top: var(--padding-24xl);
    padding-bottom: var(--padding-47xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 23px 93px;
  }
`;
const ErrorHandlerRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px var(--padding-11xs) 0px 0px;
  box-sizing: border-box;
  max-width: 100%;
  text-align: center;
  font-size: var(--font-size-23xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-semibold);
`;

const ErrorHandler = () => {
  return (
    <ErrorHandlerRoot>
      <FrameParent>
        <OurAmazingBenefitsHelpfulFWrapper>
          <OurAmazingBenefitsContainer>
            <OurAmazingBenefits>{`Our Amazing Benefits `}</OurAmazingBenefits>
            <HelpfulForYour>Helpful For Your Hiring</HelpfulForYour>
          </OurAmazingBenefitsContainer>
        </OurAmazingBenefitsHelpfulFWrapper>
        <FrameChild />
        <FrameGroup>
          <EosIconsaiParent>
            <EosIconsai alt="" src="/eosiconsai.svg" />
            <CostReduce1>
              <P>60%</P>
              <CostReduce>Cost Reduce</CostReduce>
            </CostReduce1>
            <ZeroOverheadIn>
              Zero overhead in the hiring process - promise! Source top quality
              candidates for some of the best companies
            </ZeroOverheadIn>
          </EosIconsaiParent>
          <EosIconsaiGroup>
            <EosIconsai alt="" src="/eosiconsai-1.svg" />
            <FasterRecruitmentByContainer>
              <P>50% Faster</P>
              <CostReduce>Recruitment by TAT</CostReduce>
            </FasterRecruitmentByContainer>
            <ZeroOverheadIn>
              Zero overhead in the hiring process - promise! Source top quality
              candidates for some of the best companies
            </ZeroOverheadIn>
          </EosIconsaiGroup>
          <FrameContainer>
            <FrameWrapper>
              <VectorParent>
                <VectorIcon alt="" src="/vector-7.svg" />
                <VectorIcon1 alt="" src="/vector-8.svg" />
              </VectorParent>
            </FrameWrapper>
            <HighlyContextualizedIntervieParent>
              <CostReduce1>
                <P>{`Highly Contextualized `}</P>
                <CostReduce>Interview</CostReduce>
              </CostReduce1>
              <ZeroOverheadIn>
                Al models generate highly contextualized interviews for the
                candidates based on your Company profile, Job description and
                Candidate's CV.
              </ZeroOverheadIn>
            </HighlyContextualizedIntervieParent>
          </FrameContainer>
          <FrameDiv>
            <FrameWrapper1>
              <VectorGroup>
                <VectorIcon2 alt="" src="/vector-9.svg" />
                <VectorIcon3 alt="" src="/vector-10.svg" />
                <VectorIcon4 alt="" src="/vector-11.svg" />
                <VectorIcon5 alt="" src="/vector-12.svg" />
              </VectorGroup>
            </FrameWrapper1>
            <HighlyContextualizedIntervieParent>
              <FasterRecruitmentByContainer>
                <P>{`Automated `}</P>
                <CostReduce>Scheduling</CostReduce>
              </FasterRecruitmentByContainer>
              <ZeroOverheadIn>{`Email & WhatsApp based communication for interview scheduling with automated reminders.`}</ZeroOverheadIn>
            </HighlyContextualizedIntervieParent>
          </FrameDiv>
          <EosIconsaiContainer>
            <EosIconsai alt="" src="/eosiconsai-2.svg" />
            <CostReduce1>
              <P>AI generated Interviews</P>
              <CostReduce>On what matters</CostReduce>
            </CostReduce1>
            <ZeroOverheadIn>
              0 manual interventions, completely seamless experience for the
              candidates.
            </ZeroOverheadIn>
          </EosIconsaiContainer>
          <FluenttasksApp20RegularParent>
            <EosIconsai alt="" src="/fluenttasksapp20regular.svg" />
            <CostReduce1>
              <P>in-built</P>
              <CostReduce>ATS</CostReduce>
            </CostReduce1>
            <ZeroOverheadIn>{`To manage all of your candidates & Credo verified CVs. Integrations with other ATS coming soon.`}</ZeroOverheadIn>
          </FluenttasksApp20RegularParent>
        </FrameGroup>
      </FrameParent>
    </ErrorHandlerRoot>
  );
};

export default ErrorHandler;
