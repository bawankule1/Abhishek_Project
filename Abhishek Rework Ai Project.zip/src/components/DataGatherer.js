import styled from "styled-components";
import SizeAdjuster from "./SizeAdjuster";

const ChooseYourSimple = styled.span``;
const TransparentPricing = styled.span`
  font-family: var(--font-garnett-regular);
`;
const ChooseYourSimpleContainer = styled.h1`
  margin: 0;
  width: 875px;
  position: relative;
  font-size: inherit;
  line-height: 50px;
  text-transform: capitalize;
  display: inline-block;
  max-width: 100%;
  font-family: inherit;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-15xl);
    line-height: 40px;
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
    line-height: 30px;
  }
`;
const ShapeSorter = styled.div`
  width: 1201px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl);
  box-sizing: border-box;
  max-width: 100%;
`;
const Div = styled.div`
  align-self: stretch;
  position: relative;
  font-weight: 500;
  display: inline-block;
  min-width: 14px;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
  }
`;
const Wrapper = styled.div`
  width: 14px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-11xs-5) 0px 0px;
  box-sizing: border-box;
`;
const Months = styled.div`
  flex: 1;
  position: relative;
  font-family: var(--font-garnett-medium);
  display: inline-block;
  min-width: 89px;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
  }
`;
const FrameContainer = styled.div`
  position: absolute;
  top: 34px;
  left: 0px;
  width: 109px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-7xs);
`;
const MostPopular = styled.div`
  width: 95px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 95px;
`;
const SizeScaler = styled.div`
  position: absolute;
  top: 0px;
  left: 106px;
  border-radius: 0px 0px 0px var(--br-8xs);
  background-color: var(--color-goldenrod);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-5xs) var(--padding-lg-5);
  white-space: nowrap;
  font-size: var(--font-size-sm);
  color: var(--color-gray-300);
  font-family: var(--font-garnett-medium);
`;
const FrameGroup = styled.div`
  height: 66px;
  width: 238px;
  position: relative;
`;
const FrameWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
`;
const Div1 = styled.div`
  height: 56px;
  width: 26px;
  position: relative;
  font-weight: 500;
  font-family: var(--font-space-grotesk);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  min-width: 26px;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-13xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-5xl);
  }
`;
const ShapeTransformer = styled.div`
  height: 56px;
  flex: 1;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-13xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-5xl);
  }
`;
const Month = styled.div`
  height: 38px;
  width: 61px;
  position: relative;
  font-size: var(--font-size-base);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  min-width: 61px;
`;
const Parent1 = styled.div`
  width: 225px;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  font-size: var(--font-size-21xl);
  font-family: var(--font-garnett-medium);
`;
const FrameParent = styled.div`
  margin-right: -34.5px;
  width: 296px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-base);
  font-size: var(--font-size-4xl);
`;
const SuitableForCompanies = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 28px;
`;
const Icons = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  min-height: 24px;
`;
const InterviewReadyCandidates = styled.div`
  flex: 1;
  position: relative;
`;
const IconsParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-3xs);
`;
const Icons1 = styled.img`
  height: 24px;
  width: 24px;
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
`;
const ReceivePreVettedProfiles = styled.div`
  flex: 1;
  position: relative;
  display: inline-block;
  min-width: 170px;
`;
const IconsContainer = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-3xs);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const AssistanceWithInterview = styled.div`
  flex: 1;
  position: relative;
  display: inline-block;
  min-width: 159px;
`;
const FrameDiv = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--gap-3xs);
  text-align: left;
  font-size: var(--font-size-base);
  color: var(--primary-300);
  font-family: var(--font-poppins);
`;
const SuitableForCompaniesWith5Parent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--gap-xl);
`;
const SizeAdjusterInner = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-end;
  padding: 0px var(--padding-12xs) var(--padding-lgi);
  font-family: var(--font-garnett-medium);
`;
const GetStarted = styled.div`
  width: 104px;
  position: relative;
  font-weight: 500;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  min-width: 104px;
  white-space: nowrap;
`;
const VectorIcon = styled.img`
  height: 0px;
  width: 18px;
  position: relative;
`;
const VectorIcon1 = styled.img`
  height: 14px;
  width: 7px;
  position: relative;
  margin-left: -5px;
`;
const Arrow = styled.div`
  width: 1px;
  overflow: hidden;
  flex-shrink: 0;
  display: none;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;
const SimpleButton = styled.div`
  align-self: stretch;
  border-radius: var(--br-3xs);
  background-color: var(--white);
  box-shadow: 0px 20px 40px rgba(92, 39, 192, 0.35);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-base) var(--padding-xl);
  gap: var(--gap-base);
  color: var(--primary-100);
  font-family: var(--font-poppins);
`;
const SizeAdjuster1 = styled.div`
  flex: 1;
  border-radius: var(--br-3xs);
  background-color: var(--primary-100);
  box-shadow: 0px 20px 40px rgba(118, 118, 118, 0.35);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  padding: 0px var(--padding-15xl) var(--padding-11xl);
  box-sizing: border-box;
  gap: var(--gap-27xl);
  min-width: 274px;
  max-width: 100%;
  color: var(--white);
  @media screen and (max-width: 450px) {
    gap: 23px 46px;
  }
`;
const ColorModifier = styled.div`
  width: 1197px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: var(--gap-30xl-5);
  flex-shrink: 0;
  debug_commit: f6aba90;
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 825px) {
    gap: 49.5px 25px;
  }
`;
const Step = styled.div`
  align-self: stretch;
  flex: 1;
  position: relative;
  line-height: 50px;
  text-transform: capitalize;
  font-weight: 600;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-3xl);
    line-height: 40px;
  }
`;
const Step3Wrapper = styled.div`
  align-self: stretch;
  height: 78px;
  border-radius: var(--br-3xs);
  background-color: var(--primary-300);
  overflow: hidden;
  flex-shrink: 0;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-sm) var(--padding-55xl) var(--padding-sm)
    var(--padding-56xl);
  box-sizing: border-box;
  debug_commit: f6aba90;
`;
const FrameWrapper1 = styled.div`
  width: 247px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-2xs) 0px 0px;
  box-sizing: border-box;
  text-align: left;
  font-size: var(--font-size-9xl);
  font-family: var(--font-poppins);
`;
const ColorModifierParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-199xl);
  max-width: 100%;
  text-align: center;
  font-size: var(--font-size-lg);
  font-family: var(--font-space-grotesk);
  @media screen and (max-width: 1400px) {
    flex-wrap: wrap;
    gap: 218px 109px;
    justify-content: center;
  }
  @media screen and (max-width: 825px) {
    gap: 218px 54px;
  }
  @media screen and (max-width: 450px) {
    gap: 218px 27px;
  }
`;
const DataGathererRoot = styled.section`
  width: 1340px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-70xl) var(--padding-xl);
  box-sizing: border-box;
  gap: var(--gap-48xl);
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-23xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-semibold);
  @media screen and (max-width: 1125px) {
    padding-bottom: var(--padding-39xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 825px) {
    gap: 33px 67px;
  }
  @media screen and (max-width: 450px) {
    gap: 17px 67px;
    padding-bottom: var(--padding-19xl);
    box-sizing: border-box;
  }
`;

const DataGatherer = () => {
  return (
    <DataGathererRoot>
      <ShapeSorter>
        <ChooseYourSimpleContainer>
          <ChooseYourSimple>{`Choose Your Simple, `}</ChooseYourSimple>
          <TransparentPricing>Transparent Pricing</TransparentPricing>
        </ChooseYourSimpleContainer>
      </ShapeSorter>
      <ColorModifierParent>
        <ColorModifier>
          <SizeAdjuster prop="1" month="Month" dataMerger="199.00" />
          <SizeAdjuster1>
            <FrameParent>
              <FrameWrapper>
                <FrameGroup>
                  <FrameContainer>
                    <Wrapper>
                      <Div>3</Div>
                    </Wrapper>
                    <Months>Months</Months>
                  </FrameContainer>
                  <SizeScaler>
                    <MostPopular>Most Popular</MostPopular>
                  </SizeScaler>
                </FrameGroup>
              </FrameWrapper>
              <Parent1>
                <Div1>₹</Div1>
                <ShapeTransformer>149.00</ShapeTransformer>
                <Month>/month</Month>
              </Parent1>
            </FrameParent>
            <SizeAdjusterInner>
              <SuitableForCompaniesWith5Parent>
                <SuitableForCompanies>
                  Suitable for companies with 5-10 openings
                </SuitableForCompanies>
                <FrameDiv>
                  <IconsParent>
                    <Icons alt="" src="/icons.svg" />
                    <InterviewReadyCandidates>
                      10 interview-ready candidates
                    </InterviewReadyCandidates>
                  </IconsParent>
                  <IconsParent>
                    <Icons alt="" src="/icons.svg" />
                    <InterviewReadyCandidates>
                      Unlimited job postings
                    </InterviewReadyCandidates>
                  </IconsParent>
                  <IconsContainer>
                    <Icons1 alt="" src="/icons.svg" />
                    <ReceivePreVettedProfiles>
                      Receive pre-vetted profiles within 48 hours
                    </ReceivePreVettedProfiles>
                  </IconsContainer>
                  <IconsParent>
                    <Icons alt="" src="/icons-3.svg" />
                    <InterviewReadyCandidates>
                      Dedicated account manager
                    </InterviewReadyCandidates>
                  </IconsParent>
                  <IconsContainer>
                    <Icons1 alt="" src="/icons-3.svg" />
                    <AssistanceWithInterview>
                      Assistance with interview scheduling
                    </AssistanceWithInterview>
                  </IconsContainer>
                  <IconsParent>
                    <Icons alt="" src="/icons-3.svg" />
                    <InterviewReadyCandidates>
                      Custom reports
                    </InterviewReadyCandidates>
                  </IconsParent>
                </FrameDiv>
              </SuitableForCompaniesWith5Parent>
            </SizeAdjusterInner>
            <SimpleButton>
              <GetStarted>Get Started</GetStarted>
              <Arrow>
                <VectorIcon alt="" src="/vector.svg" />
                <VectorIcon1 alt="" src="/vector-1.svg" />
              </Arrow>
            </SimpleButton>
          </SizeAdjuster1>
          <SizeAdjuster
            prop="6"
            month="Months"
            dataMerger="169.00"
            propPadding="0px var(--padding-17xl) 0px var(--padding-16xl-5)"
            propPadding1="0px var(--padding-38xl) 0px var(--padding-38xl-5)"
            propWidth="15px"
            propMinWidth="15px"
            propMinWidth1="58px"
          />
        </ColorModifier>
        <FrameWrapper1>
          <Step3Wrapper>
            <Step>Step-3</Step>
          </Step3Wrapper>
        </FrameWrapper1>
      </ColorModifierParent>
    </DataGathererRoot>
  );
};

export default DataGatherer;
