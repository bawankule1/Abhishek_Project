import styled from "styled-components";

const DiscoverTheFuture = styled.span``;
const TalentAssessment = styled.span`
  font-family: var(--font-garnett-regular);
`;
const DiscoverTheFutureContainer = styled.div`
  align-self: stretch;
  height: 118px;
  position: relative;
  font-size: var(--font-size-23xl);
  color: var(--primary-100);
  display: flex;
  align-items: center;
  font-family: var(--font-garnett-semibold);
  @media screen and (max-width: 825px) {
    font-size: var(--font-size-15xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
  }
`;
const FacingChallengesIn = styled.p`
  margin: 0;
`;
const FacingChallengesInContainer = styled.div`
  align-self: stretch;
  position: relative;
`;
const InsideThisWhitepaper = styled.b``;
const ManualVsMachineBased = styled.span`
  font-family: var(--font-poppins);
`;
const ManualVsMachineBasedHirin = styled.li`
  margin-bottom: 0px;
`;
const GenerativeAiTheSimpleExpl = styled.li``;
const ManualVsMachineBasedHirin1 = styled.ul`
  margin: 0;
  font-size: inherit;
  padding-left: var(--padding-5xl);
`;
const DiscoverTheFutureOfTalentParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-11xl);
`;
const DownloadNowFor = styled.div`
  position: relative;
  line-height: 28px;
  font-weight: 500;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 22px;
  }
`;
const CtaButton = styled.div`
  border-radius: var(--br-xl);
  background-color: var(--primary-100);
  box-shadow: 0px 8px 18px rgba(174, 93, 255, 0.46);
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-2xl) var(--padding-37xl);
  box-sizing: border-box;
  max-width: 100%;
  font-size: var(--font-size-5xl);
  color: var(--color-snow);
  @media screen and (max-width: 825px) {
    padding-left: var(--padding-9xl);
    padding-right: var(--padding-9xl);
    box-sizing: border-box;
  }
`;
const FrameParent = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-75xl);
  min-width: 502px;
  max-width: 100%;
  @media screen and (max-width: 825px) {
    gap: 47px 94px;
    min-width: 100%;
  }
  @media screen and (max-width: 450px) {
    gap: 23px 94px;
  }
`;
const WrapperRectangle39394Child = styled.img`
  height: 100%;
  width: 100%;
  max-width: 100%;
  object-fit: contain;
  position: absolute;
  left: -9px;
  top: 10px;
  transform: scale(1.049);
  @media screen and (max-width: 1125px) {
    flex: 1;
  }
`;
const WrapperRectangle = styled.div`
  height: 563px;
  width: 387px;
  position: relative;
  border-radius: var(--br-xs);
  display: flex;
  align-items: center;
  justify-content: center;
`;
const Cta = styled.div`
  flex: 1;
  background-color: var(--white);
  overflow: hidden;
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  justify-content: center;
  padding: var(--padding-62xl) var(--padding-101xl) var(--padding-91xl);
  box-sizing: border-box;
  gap: var(--gap-21xl);
  max-width: 100%;
  @media screen and (max-width: 1125px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 825px) {
    gap: 40px 20px;
    padding: var(--padding-34xl) var(--padding-41xl) var(--padding-52xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-left: var(--padding-xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const CtaWrapperRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px 0px var(--padding-49xl);
  box-sizing: border-box;
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-lg);
  color: var(--color-gray-300);
  font-family: var(--font-poppins);
  @media screen and (max-width: 1125px) {
    padding-bottom: var(--padding-25xl);
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    padding-bottom: var(--padding-10xl);
    box-sizing: border-box;
  }
`;

const FrameComponent2 = () => {
  return (
    <CtaWrapperRoot>
      <Cta>
        <FrameParent>
          <DiscoverTheFutureOfTalentParent>
            <DiscoverTheFutureContainer>
              <DiscoverTheFuture>
                <DiscoverTheFuture>{`Discover the Future of `}</DiscoverTheFuture>
                <TalentAssessment>Talent Assessment!</TalentAssessment>
              </DiscoverTheFuture>
            </DiscoverTheFutureContainer>
            <FacingChallengesInContainer>
              <FacingChallengesIn>
                Facing challenges in traditional hiring?
              </FacingChallengesIn>
              <FacingChallengesIn>
                Uncover the costs, pitfalls, and the game-changing role of
                Generative AI in recruitment.
              </FacingChallengesIn>
            </FacingChallengesInContainer>
            <FacingChallengesInContainer>
              <FacingChallengesIn>
                <InsideThisWhitepaper>
                  🔍 Inside this Whitepaper:
                </InsideThisWhitepaper>
              </FacingChallengesIn>
              <ManualVsMachineBasedHirin1>
                <ManualVsMachineBasedHirin>
                  <ManualVsMachineBased>{`Manual vs. Machine-based hiring: Costs & Challenges.`}</ManualVsMachineBased>
                </ManualVsMachineBasedHirin>
                <ManualVsMachineBasedHirin>
                  <ManualVsMachineBased>
                    The truth about "Interview as a Service."
                  </ManualVsMachineBased>
                </ManualVsMachineBasedHirin>
                <GenerativeAiTheSimpleExpl>
                  <ManualVsMachineBased>
                    Generative AI: The simple explanation. Optimize Your Hiring
                    Process Today!
                  </ManualVsMachineBased>
                </GenerativeAiTheSimpleExpl>
              </ManualVsMachineBasedHirin1>
            </FacingChallengesInContainer>
          </DiscoverTheFutureOfTalentParent>
          <CtaButton>
            <DownloadNowFor>
              Download Now for Smarter Recruitment
            </DownloadNowFor>
          </CtaButton>
        </FrameParent>
        <WrapperRectangle>
          <WrapperRectangle39394Child
            loading="lazy"
            alt=""
            src="/rectangle-39394@2x.png"
          />
        </WrapperRectangle>
      </Cta>
    </CtaWrapperRoot>
  );
};

export default FrameComponent2;
