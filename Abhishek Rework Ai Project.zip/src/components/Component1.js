import styled from "styled-components";

const ReworkHasBeen = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 27px;
`;
const FrameChild = styled.img`
  height: 50px;
  width: 50px;
  position: relative;
  border-radius: 50%;
  object-fit: cover;
`;
const TheresaWebb = styled.div`
  align-self: stretch;
  position: relative;
  line-height: 32px;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lgi);
    line-height: 26px;
  }
`;
const HrManagerAmazon = styled.div`
  position: relative;
  font-size: var(--font-size-base);
  line-height: 20px;
  font-weight: 500;
  font-family: var(--font-poppins);
  color: var(--neutrals-300);
`;
const Container = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0px var(--padding-81xl-3) 0px 0px;
  box-sizing: border-box;
  min-width: 178px;
  @media screen and (max-width: 450px) {
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const EllipseParent = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: var(--gap-lgi);
  font-size: var(--font-size-5xl);
  color: var(--primary-100);
  font-family: var(--font-garnett-regular);
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const ComponentRoot = styled.div`
  align-self: stretch;
  border-radius: var(--br-base);
  background-color: var(--primary-300);
  box-shadow: 0px 4px 24px rgba(0, 0, 0, 0.15);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xl);
  gap: var(--gap-11xl);
  text-align: left;
  font-size: var(--font-size-lg);
  color: var(--color-black);
  font-family: var(--font-poppins);
`;

const Component1 = ({
  reworkHasBeenAGreatWayToM,
  ellipse2,
  theresaWebb,
  hRManagerAmazon,
}) => {
  return (
    <ComponentRoot>
      <ReworkHasBeen>{reworkHasBeenAGreatWayToM}</ReworkHasBeen>
      <EllipseParent>
        <FrameChild loading="lazy" alt="" src={ellipse2} />
        <Container>
          <TheresaWebb>{theresaWebb}</TheresaWebb>
          <HrManagerAmazon>{hRManagerAmazon}</HrManagerAmazon>
        </Container>
      </EllipseParent>
    </ComponentRoot>
  );
};

export default Component1;
