import styled from "styled-components";

const UploadDocuments = styled.div`
  width: 339.3px;
  position: relative;
  line-height: 29px;
  font-weight: 600;
  display: inline-block;
  max-width: 100%;
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
    line-height: 23px;
  }
`;
const ShortlistTheMost = styled.div`
  align-self: stretch;
  position: relative;
`;
const ShortlistTheMostQualifiedCWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const StepsInner = styled.div`align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0px var(--padding-sm) var(--padding-lgi);
  font-size: var(--font-size-lg);
  color: var(--color-dimgray-100);
  padding: ${(p) => p.propPadding1}
  min-height: ${(p) => p.propMinHeight}
`;
const WrapperFrame48095633Child = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
  position: absolute;
  left: 0px;
  top: 4px;
  transform: scale(1.333);
`;
const WrapperFrame = styled.div`
  width: 84px;
  height: 84px;
  position: absolute;
  margin: 0 !important;
  top: 0px;
  right: 0.3px;
  border-radius: 0px 0px 0px var(--br-3xs);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2;
`;
const StepsRoot = styled.div`
  flex: 1;
  background-color: var(--color-white);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  padding: 0px var(--padding-12xs-3) var(--padding-41xl) var(--padding-11xl);
  box-sizing: border-box;
  position: relative;
  min-width: 299px;
  min-height: 282px;
  max-width: 100%;
  text-align: left;
  font-size: var(--font-size-3xl);
  color: var(--color-black);
  font-family: var(--font-poppins);
  padding: ${(p) => p.propPadding};
`;

const Steps = ({
  uploadDocuments,
  shortlistTheMostQualified,
  frame48095633,
  propPadding,
  propPadding1,
  propMinHeight,
}) => {
  return (
    <StepsRoot propPadding={propPadding}>
      <UploadDocuments>{uploadDocuments}</UploadDocuments>
      <StepsInner propPadding1={propPadding1} propMinHeight={propMinHeight}>
        <ShortlistTheMostQualifiedCWrapper>
          <ShortlistTheMost>{shortlistTheMostQualified}</ShortlistTheMost>
        </ShortlistTheMostQualifiedCWrapper>
      </StepsInner>
      <WrapperFrame>
        <WrapperFrame48095633Child loading="lazy" alt="" src={frame48095633} />
      </WrapperFrame>
    </StepsRoot>
  );
};

export default Steps;
